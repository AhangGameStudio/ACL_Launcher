// ACL 联机中继服务端
// 用法：node acl-relay.js [监听端口]     默认 25566
// 协议（纯 TCP，一行握手后转为裸流）：
//   HOST <6位码>   房主连入并登记房间
//   JOIN <6位码>   访客连入，与房主配对后双向透传
// 说明：房主与访客都是"主动连出"，双方都不需要公网 IP 或端口映射。

const net = require('net');

const PORT = parseInt(process.argv[2] || '25566', 10);
const rooms = new Map(); // code -> { host: socket, waiting: [socket] }
const PENDING_TTL = 30 * 1000;

function log(...a) {
  console.log(new Date().toISOString().slice(11, 19), ...a);
}

function pipe(a, b, aRest, bRest) {
  // 关键：先暂停，避免 flowing 模式下的数据在接管前被丢弃
  try { a.pause(); } catch {}
  try { b.pause(); } catch {}
  a.pipe(b);
  b.pipe(a);
  if (aRest && aRest.length) { try { b.write(aRest); } catch {} }
  if (bRest && bRest.length) { try { a.write(bRest); } catch {} }
  const done = () => {
    try { a.destroy(); } catch {}
    try { b.destroy(); } catch {}
  };
  a.on('error', done);
  b.on('error', done);
  a.on('close', done);
  b.on('close', done);
}

const server = net.createServer((socket) => {
  socket.setNoDelay(true); // 关闭 Nagle，降低小包延迟
  let buf = Buffer.alloc(0);
  let handled = false;

  const onData = (chunk) => {
    if (handled) return;
    buf = Buffer.concat([buf, chunk]);
    const nl = buf.indexOf(0x0a);
    if (nl < 0) {
      if (buf.length > 64) socket.destroy();
      return;
    }
    handled = true;
    // 必须先 pause 再摘监听，否则流向模式会继续把后续数据丢弃
    socket.pause();
    socket.removeListener('data', onData);

    const line = buf.slice(0, nl).toString('utf8').trim();
    const rest = buf.slice(nl + 1);
    const [cmd, code] = line.split(/\s+/);

    if (!/^\d{6}$/.test(code || '')) {
      log('非法房间码', line);
      socket.destroy();
      return;
    }

    if (cmd === 'HOST') {
      const prev = rooms.get(code);
      if (prev && prev.host) {
        log('房间号被占用，拒绝', code);
        socket.destroy();
        return;
      }
      const room = prev || { host: null, waiting: [] };
      room.host = socket;
      rooms.set(code, room);
      log('房主登记', code, '等待人数', room.waiting.length);

      // 把已经等着的访客放进来
      while (room.waiting.length) {
        const visitor = room.waiting.shift();
        log('配对（存量）', code);
        pipe(socket, visitor, rest, null);
        room.host = null;
        rooms.delete(code);
        return;
      }

      socket.on('close', () => {
        const r = rooms.get(code);
        if (r && r.host === socket) {
          rooms.delete(code);
          r.waiting.forEach((w) => { try { w.destroy(); } catch {} });
          log('房主断开，房间销毁', code);
        }
      });
      return;
    }

    if (cmd === 'JOIN') {
      const room = rooms.get(code);
      if (room && room.host) {
        log('配对', code);
        const host = room.host;
        rooms.delete(code);
        pipe(host, socket, null, rest);
        return;
      }
      // 房主还没到，先排队
      if (!room) rooms.set(code, { host: null, waiting: [socket] });
      else room.waiting.push(socket);
      log('访客等待房主', code, '队列', (rooms.get(code) || {}).waiting?.length || 0);
      const timer = setTimeout(() => {
        const r = rooms.get(code);
        if (r && r.waiting.includes(socket)) {
          r.waiting = r.waiting.filter((x) => x !== socket);
          if (!r.host && r.waiting.length === 0) rooms.delete(code);
          log('访客等待超时', code);
          try { socket.destroy(); } catch {}
        }
      }, PENDING_TTL);
      socket.on('close', () => clearTimeout(timer));
      return;
    }

    socket.destroy();
  };

  socket.on('data', onData);
  socket.on('error', () => {});
});

server.listen(PORT, () => log('ACL 中继已监听', PORT));
